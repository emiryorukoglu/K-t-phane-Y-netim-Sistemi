import tkinter as tk
from tkinter import ttk, messagebox, Toplevel, simpledialog
import json
import os
import datetime
import uuid


BOOKS_FILE = "kitaplar.json"
MEMBERS_FILE = "uyeler.json"
LENDINGS_FILE = "odunc_islemleri.json"


def load_data(filename):
    if not os.path.exists(filename):
        return []
    try:
        with open(filename, "r", encoding="utf-8") as file:
            content = file.read()
            if not content.strip():
                return []
            data = json.loads(content)
            if not isinstance(data, list):
                messagebox.showwarning("Veri Hatası", f"{filename} geçerli bir liste formatında değil. Veri sıfırlandı.", icon='warning', parent=root if 'root' in globals() else None)
                return []
            return data
    except json.JSONDecodeError:
        messagebox.showwarning("Yükleme Hatası", f"{filename} dosyası okunamadı veya bozuk. Boş liste ile başlanıyor.", icon='warning', parent=root if 'root' in globals() else None)
        return []
    except PermissionError:
        messagebox.showerror("İzin Hatası", f"{filename} dosyasına erişim izni yok.", icon='error', parent=root if 'root' in globals() else None)
        return []
    except Exception as e:
        messagebox.showerror("Genel Hata", f"Veri yüklenirken bir hata oluştu ({filename}): {str(e)}", icon='error', parent=root if 'root' in globals() else None)
        return []

def save_data(data, filename):
    try:
        with open(filename, "w", encoding="utf-8") as file:
            json.dump(data, file, indent=4, ensure_ascii=False)
    except PermissionError:
        messagebox.showerror("İzin Hatası", f"{filename} dosyasına yazma izni yok.", icon='error', parent=root if 'root' in globals() else None)
    except Exception as e:
        messagebox.showerror("Kaydetme Hatası", f"Veri kaydedilirken bir hata oluştu ({filename}): {str(e)}", icon='error', parent=root if 'root' in globals() else None)


def generate_short_unique_id(prefix="ID-"):
    return prefix + str(uuid.uuid4())[:8].upper()


def safe_dialog_interaction(dialog_class, parent, *args, **kwargs):
    try:
        dialog = dialog_class(parent, *args, **kwargs)
        return dialog.result
    except Exception as e:
        messagebox.showerror("Diyalog Hatası", f"Pencere açılırken bir hata oluştu: {str(e)}", parent=parent)
        return None


class BookDialog(Toplevel):
    def __init__(self, parent, book_to_edit=None):
        super().__init__(parent)
        self.transient(parent)
        self.parent = parent
        self.book_to_edit = book_to_edit
        self.result = None
        self.title("Kitap Düzenle" if book_to_edit else "Yeni Kitap Ekle")
        self.geometry("400x230")
        self.resizable(False, False)
        main_frame = ttk.Frame(self, padding="10")
        main_frame.pack(expand=True, fill=tk.BOTH)
        
        ttk.Label(main_frame, text="Kitap ID:").grid(row=0, column=0, padx=5, pady=5, sticky="w")
        self.id_entry = ttk.Entry(main_frame, width=35)
        self.id_entry.grid(row=0, column=1, padx=5, pady=5, sticky="ew")
        
        ttk.Label(main_frame, text="Kitap Adı:").grid(row=1, column=0, padx=5, pady=5, sticky="w")
        self.title_entry = ttk.Entry(main_frame, width=35)
        self.title_entry.grid(row=1, column=1, padx=5, pady=5, sticky="ew")
        
        ttk.Label(main_frame, text="Yazar:").grid(row=2, column=0, padx=5, pady=5, sticky="w")
        self.author_entry = ttk.Entry(main_frame, width=35)
        self.author_entry.grid(row=2, column=1, padx=5, pady=5, sticky="ew")
        
        ttk.Label(main_frame, text="Durum:").grid(row=3, column=0, padx=5, pady=5, sticky="w")
        self.status_var = tk.StringVar()
        self.status_options = ["Mevcut", "Mevcut Değil", "Kayıp"]
        self.status_combobox = ttk.Combobox(main_frame, textvariable=self.status_var, values=self.status_options, state="readonly", width=33)
        self.status_combobox.grid(row=3, column=1, padx=5, pady=5, sticky="ew")

        if self.book_to_edit:
            self.id_entry.insert(0, self.book_to_edit.get("id", ""))
            self.id_entry.config(state="readonly") 
            self.title_entry.insert(0, self.book_to_edit.get("title", ""))
            self.author_entry.insert(0, self.book_to_edit.get("author", ""))
            active_lendings = load_data(LENDINGS_FILE)
            is_currently_lent = any(l['book_id'] == self.book_to_edit.get("id") and l.get('return_date') is None for l in active_lendings)
            if is_currently_lent:
                self.status_var.set("Ödünçte (Değiştirilemez)")
                self.status_combobox.config(state="disabled")
            else:
                current_status = self.book_to_edit.get("status", "Mevcut")
                self.status_var.set(current_status if current_status in self.status_options else "Mevcut")
        else: 
            self.status_var.set("Mevcut")
            
        main_frame.columnconfigure(1, weight=1)
        button_frame = ttk.Frame(main_frame)
        button_frame.grid(row=4, column=0, columnspan=2, pady=(15,5))
        ttk.Button(button_frame, text="Kaydet", command=self.ok_pressed).pack(side=tk.LEFT, padx=5)
        ttk.Button(button_frame, text="İptal", command=self.cancel_pressed).pack(side=tk.LEFT, padx=5)
        
        self.protocol("WM_DELETE_WINDOW", self.cancel_pressed)
        self.grab_set()
        self.focus_set_initial()
        try: 
            self.wait_window()
        except tk.TclError as e: 
            print(f"BookDialog wait_window TclError: {e}")
            self.result = None

    def focus_set_initial(self):
        if self.book_to_edit: 
            self.title_entry.focus_set()
        else: 
            self.id_entry.focus_set()
            
    def ok_pressed(self):
        try:
            book_id = self.id_entry.get().strip()
            title = self.title_entry.get().strip()
            author = self.author_entry.get().strip()
            status = self.book_to_edit.get("status", "Mevcut") if self.status_combobox.cget('state') == 'disabled' else self.status_var.get()
            
            if not book_id : 
                messagebox.showwarning("Eksik Bilgi", "Kitap ID alanı boş bırakılamaz.", parent=self); return
            if not title or not author:
                messagebox.showwarning("Eksik Bilgi", "Kitap Adı ve Yazar alanları doldurulmalıdır.", parent=self); return
            if not status or (self.status_combobox.cget('state') != 'disabled' and status not in self.status_options):
                messagebox.showwarning("Geçersiz Durum", "Lütfen geçerli bir durum seçin.", parent=self); return
            
            if not self.book_to_edit and any(b["id"] == book_id for b in load_data(BOOKS_FILE)):
                messagebox.showwarning("Hata", f"'{book_id}' ID'li kitap zaten mevcut!", parent=self); return
            
            self.result = {"id": book_id, "title": title, "author": author, "status": status}
        except Exception as e: 
            messagebox.showerror("Hata", f"Kitap bilgileri işlenirken bir hata oluştu: {str(e)}", parent=self); self.result = None
        finally: 
            self.destroy()
            
    def cancel_pressed(self): 
        self.result = None; self.destroy()

def add_book_handler():
    result = safe_dialog_interaction(BookDialog, root)
    if result:
        try:
            books = load_data(BOOKS_FILE); books.append(result); save_data(books, BOOKS_FILE)
            messagebox.showinfo("Başarılı", f"'{result['title']}' adlı kitap eklendi!", parent=root)
            refresh_book_list_if_open(True)
        except Exception as e: 
            messagebox.showerror("Kayıt Hatası", f"Kitap kaydedilirken bir sorun oluştu: {str(e)}", parent=root)

def edit_book_handler():
    book_id_to_edit = simpledialog.askstring("Kitap Düzenle", "Düzenlenecek kitabın ID'sini girin:", parent=root)
    if not book_id_to_edit: return
    try:
        books = load_data(BOOKS_FILE); book_found = next((b for b in books if b["id"] == book_id_to_edit), None)
        if not book_found: 
            messagebox.showerror("Hata", f"'{book_id_to_edit}' ID'li kitap bulunamadı.", parent=root); return
        book_idx = books.index(book_found)
        result = safe_dialog_interaction(BookDialog, root, book_to_edit=book_found)
        if result:
            books[book_idx] = result; save_data(books, BOOKS_FILE)
            messagebox.showinfo("Başarılı", f"'{result['title']}' adlı kitap güncellendi!", parent=root)
            refresh_book_list_if_open(True)
    except Exception as e: 
        messagebox.showerror("Düzenleme Hatası", f"Kitap düzenlenirken bir sorun oluştu: {str(e)}", parent=root)

# --- Üye İşlemleri ---
class MemberDialog(Toplevel):
    def __init__(self, parent, member_to_edit=None):
        super().__init__(parent)
        self.transient(parent)
        self.parent = parent
        self.member_to_edit = member_to_edit
        self.result = None
        self.title("Yeni Üye Ekle" if not member_to_edit else "Üye Düzenle")
        self.geometry("420x300") 
        self.resizable(False, False)
        
        main_frame = ttk.Frame(self, padding="10")
        main_frame.pack(expand=True, fill=tk.BOTH)

        ttk.Label(main_frame, text="Üye ID:").grid(row=0, column=0, padx=5, pady=5, sticky="w")
        self.id_entry = ttk.Entry(main_frame, width=38) 
        self.id_entry.grid(row=0, column=1, padx=5, pady=5, sticky="ew")

        ttk.Label(main_frame, text="Ad Soyad:").grid(row=1, column=0, padx=5, pady=5, sticky="w")
        self.name_entry = ttk.Entry(main_frame, width=38)
        self.name_entry.grid(row=1, column=1, padx=5, pady=5, sticky="ew")
        
        main_frame.columnconfigure(1, weight=1) 

        contact_frame = ttk.LabelFrame(main_frame, text="İletişim Bilgileri", padding="10")
        contact_frame.grid(row=2, column=0, columnspan=2, padx=5, pady=(10,5), sticky="ew")

        ttk.Label(contact_frame, text="Telefon 1:").grid(row=0, column=0, padx=5, pady=3, sticky="w")
        self.phone1_entry = ttk.Entry(contact_frame, width=30)
        self.phone1_entry.grid(row=0, column=1, padx=5, pady=3, sticky="ew")

        ttk.Label(contact_frame, text="Telefon 2:").grid(row=1, column=0, padx=5, pady=3, sticky="w")
        self.phone2_entry = ttk.Entry(contact_frame, width=30)
        self.phone2_entry.grid(row=1, column=1, padx=5, pady=3, sticky="ew")

        ttk.Label(contact_frame, text="E-posta:").grid(row=2, column=0, padx=5, pady=3, sticky="w")
        self.email_entry = ttk.Entry(contact_frame, width=30)
        self.email_entry.grid(row=2, column=1, padx=5, pady=3, sticky="ew")
        
        contact_frame.columnconfigure(1, weight=1) 

        if self.member_to_edit: 
            self.id_entry.insert(0, self.member_to_edit.get("id",""))
            self.name_entry.insert(0, self.member_to_edit.get("name",""))
            self.phone1_entry.insert(0, self.member_to_edit.get("phone1",""))
            self.phone2_entry.insert(0, self.member_to_edit.get("phone2",""))
            self.email_entry.insert(0, self.member_to_edit.get("email",""))
        else: 
            new_member_id = uuid.uuid4().hex 
            self.id_entry.insert(0, new_member_id)
        
        self.id_entry.config(state="readonly") 

        button_frame = ttk.Frame(main_frame)
        button_frame.grid(row=3, column=0, columnspan=2, pady=(15,5))
        ttk.Button(button_frame, text="Kaydet", command=self.ok_pressed).pack(side=tk.LEFT, padx=5)
        ttk.Button(button_frame, text="İptal", command=self.cancel_pressed).pack(side=tk.LEFT, padx=5)
        
        self.protocol("WM_DELETE_WINDOW", self.cancel_pressed)
        self.grab_set()
        self.focus_set_initial()
        try: 
            self.wait_window()
        except tk.TclError as e: 
            print(f"MemberDialog TclError: {e}")
            self.result=None
            
    def focus_set_initial(self):
        self.name_entry.focus_set() 
            
    def ok_pressed(self):
        try:
            member_id = self.id_entry.get().strip() 
            name = self.name_entry.get().strip()
            phone1 = self.phone1_entry.get().strip()
            phone2 = self.phone2_entry.get().strip()
            email = self.email_entry.get().strip()

            if not name: 
                messagebox.showwarning("Eksik Bilgi","Ad Soyad alanı gereklidir.", parent=self)
                return
            self.result = {"id": member_id, "name": name, "phone1": phone1, "phone2": phone2, "email": email}
        except Exception as e: 
            messagebox.showerror("Hata",f"Üye bilgileri işlenirken hata: {str(e)}", parent=self)
            self.result=None
        finally: 
            self.destroy()
            
    def cancel_pressed(self): 
        self.result=None
        self.destroy()

def add_member_handler():
    result = safe_dialog_interaction(MemberDialog, root)
    if result: 
        try:
            data = load_data(MEMBERS_FILE)
            data.append(result)
            save_data(data, MEMBERS_FILE)
            messagebox.showinfo("Başarılı", f"'{result['name']}' adlı üye eklendi!", parent=root)
            refresh_member_list_if_open(True)
        except Exception as e: 
            messagebox.showerror("Kayıt Hatası", f"Üye kaydı sırasında bir hata oluştu: {str(e)}", parent=root)

def delete_member_handler(selected_member_id):
    if not selected_member_id:
        messagebox.showwarning("Seçim Yok", "Lütfen silinecek bir üye seçin.", parent=root)
        return

    try:
        lendings = load_data(LENDINGS_FILE)
        active_loans = [l for l in lendings if l.get("member_id") == selected_member_id and l.get("return_date") is None]
        if active_loans:
            messagebox.showerror("Silme Hatası", "Bu üyenin aktif ödünç aldığı kitap/kitaplar var. Silme işlemi yapılamaz.", parent=root)
            return

        confirm = messagebox.askyesno("Üye Sil", f"'{selected_member_id}' ID'li üyeyi silmek istediğinizden emin misiniz?\nBu işlem geri alınamaz.", parent=root)
        if confirm:
            members = load_data(MEMBERS_FILE)
            member_to_delete = next((m for m in members if m["id"] == selected_member_id), None)
            if member_to_delete:
                members.remove(member_to_delete)
                save_data(members, MEMBERS_FILE)
                messagebox.showinfo("Başarılı", f"'{selected_member_id}' ID'li üye silindi.", parent=root)
                refresh_member_list_if_open(True)
            else:
                messagebox.showerror("Hata", "Silinecek üye bulunamadı.", parent=root)
    except Exception as e:
        messagebox.showerror("Silme Hatası", f"Üye silinirken bir hata oluştu: {str(e)}", parent=root)



class LendBookDialog(Toplevel):
    def __init__(self, parent):
        super().__init__(parent)
        self.transient(parent)
        self.parent=parent
        self.title("Kitap Ödünç Ver")
        self.geometry("500x230") 
        self.resizable(False,False)
        self.result=None
        mf=ttk.Frame(self,padding="10")
        mf.pack(expand=True,fill=tk.BOTH)
        
        ttk.Label(mf,text="Kitap Seçin:").grid(row=0,column=0,padx=5,pady=5,sticky="w")
        self.book_v=tk.StringVar()
        self.book_cb=ttk.Combobox(mf,textvariable=self.book_v,state="readonly", width=50) 
        self.book_cb.grid(row=0,column=1,padx=5,pady=5,sticky="ew")
        self.all_books_data_for_lending = load_data(BOOKS_FILE) 
        self.all_lendings_data_for_lending = load_data(LENDINGS_FILE) 
        self.populate_all_books_with_status() 

        ttk.Label(mf,text="Üye Seçin:").grid(row=1,column=0,padx=5,pady=5,sticky="w")
        self.member_v=tk.StringVar()
        self.member_cb=ttk.Combobox(mf,textvariable=self.member_v,state="readonly",width=50) 
        self.member_cb.grid(row=1,column=1,padx=5,pady=5,sticky="ew")
        self.pop_members()
        
        mf.columnconfigure(1,weight=1)
        bf=ttk.Frame(mf)
        bf.grid(row=2,column=0,columnspan=2,pady=15)
        ttk.Button(bf,text="Ödünç Ver",command=self.ok).pack(side=tk.LEFT,padx=5)
        ttk.Button(bf,text="İptal",command=self.cancel).pack(side=tk.LEFT,padx=5)
        
        self.protocol("WM_DELETE_WINDOW",self.cancel)
        self.grab_set()
        try: 
            self.wait_window()
        except tk.TclError as e: 
            print(f"LendDialog TclError: {e}")
            self.result=None
            
    def populate_all_books_with_status(self):
        all_books_display = []
        self.book_map={}
        for bk in self.all_books_data_for_lending:
            effective_status = get_book_display_status(bk, self.all_lendings_data_for_lending)
            disp=f"{bk['title']} ({bk['id']}) - Durum: {effective_status}"
            all_books_display.append(disp)
            self.book_map[disp] = bk['id'] 
        
        self.book_cb['values'] = all_books_display
        if all_books_display: 
            self.book_cb.current(0)
        else: 
            self.book_v.set("Sistemde hiç kitap bulunmuyor.")
            self.book_cb.config(state="disabled")
            
    def pop_members(self):
        mems=load_data(MEMBERS_FILE)
        mem_list_disp=[]
        self.member_map={}
        for mem in mems: 
            disp=f"{mem['name']} ({mem['id']})"
            mem_list_disp.append(disp)
            self.member_map[disp]=mem['id']
        self.member_cb['values']=mem_list_disp
        if mem_list_disp: 
            self.member_cb.current(0)
        else: 
            self.member_v.set("Kayıtlı üye bulunamadı.")
            self.member_cb.config(state="disabled")
            
    def ok(self):
        try:
            if self.book_cb.cget('state')=='disabled' or self.member_cb.cget('state')=='disabled': 
                messagebox.showwarning("Seçim Yapılamaz","Kitap veya üye seçimi yapılamıyor.",parent=self)
                return
            selected_book_display_text = self.book_v.get()
            selected_member_display_text = self.member_v.get()

            if not selected_book_display_text or not selected_member_display_text or \
               selected_book_display_text == "Sistemde hiç kitap bulunmuyor." or \
               selected_member_display_text == "Kayıtlı üye bulunamadı.": 
                messagebox.showwarning("Eksik Seçim","Lütfen bir kitap ve bir üye seçin.",parent=self)
                return

            book_id = self.book_map.get(selected_book_display_text)
            member_id = self.member_map.get(selected_member_display_text)

            if not book_id or not member_id: 
                messagebox.showerror("Hata","Kitap veya üye ID'si alınamadı. Seçimi kontrol edin.",parent=self)
                return
            
            
            selected_book_data = next((b for b in self.all_books_data_for_lending if b['id'] == book_id), None)
            if not selected_book_data: 
                 messagebox.showerror("Hata","Seçilen kitap veritabanında bulunamadı.", parent=self); return

            effective_status_of_selected_book = get_book_display_status(selected_book_data, self.all_lendings_data_for_lending)
            
            if effective_status_of_selected_book != "Mevcut":
                messagebox.showerror("Ödünç Verilemez", f"Bu kitap şu anda ödünç verilemez. Durumu: {effective_status_of_selected_book}", parent=self)
                return
                
            self.result={"lending_id":generate_short_unique_id("LND-"),"book_id":book_id,"member_id":member_id,
                           "lend_date":datetime.date.today().isoformat(),"return_date":None}
        except Exception as e: 
            messagebox.showerror("Hata",f"Ödünç verme bilgileri işlenirken bir hata oluştu: {str(e)}",parent=self)
            self.result=None
        finally: 
            self.destroy()
            
    def cancel(self): 
        self.result=None
        self.destroy()

def lend_book_handler():
    try:
        
        if not load_data(BOOKS_FILE): 
            messagebox.showinfo("Bilgi","Sistemde hiç kitap bulunmuyor.",parent=root); return
        if not load_data(MEMBERS_FILE):
            messagebox.showinfo("Bilgi","Sistemde kayıtlı üye bulunmuyor.",parent=root); return

        result = safe_dialog_interaction(LendBookDialog,root)
        if result: 
            lendings_data=load_data(LENDINGS_FILE)
            lendings_data.append(result)
            save_data(lendings_data,LENDINGS_FILE)
            messagebox.showinfo("Başarılı","Kitap başarıyla ödünç verildi!",parent=root)
            refresh_book_list_if_open(True)
            refresh_lending_list_if_open(True)
    except Exception as e:
        messagebox.showerror("Ödünç Verme Hatası",f"İşlem sırasında bir hata oluştu: {str(e)}",parent=root)


def sort_treeview_column(tv, col_display_name, reverse, columns_config):
    col_id = next((c['id'] for c in columns_config if c['display'] == col_display_name), None)
    col_data_type = next((c.get('type', 'text') for c in columns_config if c['display'] == col_display_name), 'text')
    if not col_id: return

    try:
        l = [(tv.set(k, col_display_name), k) for k in tv.get_children('')]
        if col_data_type == 'numeric':
            l.sort(key=lambda t: float(t[0]) if t[0] and t[0].replace('.', '', 1).replace('-', '', 1).isdigit() else -float('inf'), reverse=reverse)
        elif col_data_type == 'date':
            l.sort(key=lambda t: datetime.datetime.strptime(t[0], '%Y-%m-%d').date() if t[0] else datetime.date.min, reverse=reverse)
        else: 
            l.sort(key=lambda t: str(t[0]).lower() if t[0] else '', reverse=reverse)
        for index, (val, k) in enumerate(l): tv.move(k, '', index)
        tv.heading(col_display_name, command=lambda _cd=col_display_name, _cc=columns_config: sort_treeview_column(tv, _cd, not reverse, _cc))
    except ValueError: 
        l.sort(key=lambda t: str(t[0]).lower() if t[0] else '', reverse=reverse)
        for index, (val, k) in enumerate(l): tv.move(k, '', index)
        tv.heading(col_display_name, command=lambda _cd=col_display_name, _cc=columns_config: sort_treeview_column(tv, _cd, not reverse, _cc))
    except Exception as e: print(f"Sıralama hatası ({col_display_name}): {e}")


opened_list_windows = {}

def create_list_window(title_key, window_title, all_items_original, columns_config,
                       search_config, filter_configs=None, item_actions=None):
    global opened_list_windows
    if opened_list_windows.get(title_key) and opened_list_windows[title_key].winfo_exists():
        opened_list_windows[title_key].destroy() 
    
    list_window = Toplevel(root)
    list_window.title(window_title)
    list_window.geometry("950x650")
    opened_list_windows[title_key] = list_window
    all_items = list(all_items_original) 

    controls_frame = ttk.Frame(list_window, padding=(10, 10, 10, 5))
    controls_frame.pack(fill=tk.X)

    search_outer_frame = ttk.Frame(controls_frame)
    search_outer_frame.pack(fill=tk.X, pady=(0,5))
    ttk.Label(search_outer_frame, text="Ara:").pack(side=tk.LEFT, padx=(0,5))
    search_var = tk.StringVar()
    search_entry = ttk.Entry(search_outer_frame, textvariable=search_var, width=35)
    search_entry.pack(side=tk.LEFT, expand=True, fill=tk.X, padx=5)
    
    filter_widgets = {}
    if filter_configs:
        filter_outer_frame = ttk.Frame(controls_frame)
        filter_outer_frame.pack(fill=tk.X, pady=(0,10))
        for config in filter_configs:
            f_key = config["data_key"]
            f_label = config["label"]
            
            f_options_source = config.get("options_override")
            if f_options_source: 
                f_options = list(f_options_source) 
                if "Tümü" not in f_options: 
                    f_options.insert(0, "Tümü")
            else: 
                unique_options = sorted(list(set(str(item.get(f_key, '')) for item in all_items if item.get(f_key) is not None and str(item.get(f_key, '')))))
                f_options = ["Tümü"] + unique_options

            ttk.Label(filter_outer_frame, text=f"{f_label}:").pack(side=tk.LEFT, padx=(10,2))
            var = tk.StringVar(value="Tümü")
            combo = ttk.Combobox(filter_outer_frame, textvariable=var, values=f_options, state="readonly", width=18)
            combo.pack(side=tk.LEFT, padx=2)
            filter_widgets[f_key] = var
    
    info_message_frame = ttk.Frame(list_window, padding=(10, 0, 10, 5))
    info_message_frame.pack(fill=tk.X)
    info_message_var = tk.StringVar()
    info_message_label = ttk.Label(info_message_frame, textvariable=info_message_var, foreground="darkorange", font=("TkDefaultFont", 9, "italic"))
    
    tree_container_frame = ttk.Frame(list_window, padding=(10,0,10,10))
    tree_container_frame.pack(expand=True, fill=tk.BOTH)
    
    tree_columns_display = [c['display'] for c in columns_config]
    tree = ttk.Treeview(tree_container_frame, columns=tree_columns_display, show="headings", selectmode="browse")
    
    style = ttk.Style(list_window) 
    style.configure("Treeview", rowheight=25) 
    tree.tag_configure('oddrow', background='#f0f0f0')
    tree.tag_configure('evenrow', background='white')

    for config_col in columns_config:
        tree.heading(config_col['display'], text=config_col['display'], 
                      command=lambda _cd=config_col['display'], _cc=columns_config: sort_treeview_column(tree, _cd, False, _cc))
        tree.column(config_col['display'], anchor=tk.W, minwidth=config_col.get('minwidth', 80), 
                    width=config_col.get('width', 150), stretch=config_col.get('stretch', tk.YES))
    
    vsb = ttk.Scrollbar(tree_container_frame, orient="vertical", command=tree.yview)
    tree.configure(yscrollcommand=vsb.set)
    hsb = ttk.Scrollbar(tree_container_frame, orient="horizontal", command=tree.xview)
    tree.configure(xscrollcommand=hsb.set)
    tree.grid(row=0, column=0, sticky='nsew')
    vsb.grid(row=0, column=1, sticky='ns')
    hsb.grid(row=1, column=0, sticky='ew')
    tree_container_frame.grid_rowconfigure(0, weight=1)
    tree_container_frame.grid_columnconfigure(0, weight=1)

    def update_tree_display(*args): 
        current_search_term = search_var.get().lower().strip()
        active_filters = {fk:fv.get() for fk,fv in filter_widgets.items() if fv.get() != "Tümü"}
        processed_items = list(all_items)

        if active_filters:
            processed_items = [
                item for item in processed_items 
                if all(str(item.get(f_key, '')).lower() == f_value.lower() for f_key, f_value in active_filters.items())
            ]
        
        if current_search_term:
            processed_items = [
                item for item in processed_items 
                if any(current_search_term in str(item.get(s_key, '')).lower() for s_key in search_config["keys"])
            ]

        for i in tree.get_children(): 
            tree.delete(i)
        
        current_info_text = ""
        if not all_items:
            current_info_text = "ℹ️ Sistemde gösterilecek veri bulunmuyor."
        elif not processed_items and (current_search_term or active_filters):
            current_info_text = f"⚠️ '{current_search_term if current_search_term else 'Aktif filtreler'}' için sonuç bulunamadı."
        elif current_search_term and active_filters:
            current_info_text = "ℹ️ Liste, arama ve filtre kriterlerine göre özelleştirilmiştir."
        elif current_search_term:
            current_info_text = "ℹ️ Liste, arama kriterlerine göre özelleştirilmiştir."
        elif active_filters:
            current_info_text = "ℹ️ Liste, aktif filtrelere göre özelleştirilmiştir."
        
        if current_info_text:
            info_message_var.set(current_info_text)
            if not info_message_label.winfo_ismapped():
                info_message_label.pack(fill=tk.X, pady=(0,5))
        else:
            if info_message_label.winfo_ismapped():
                info_message_label.pack_forget()
            info_message_var.set("")

        for idx, item in enumerate(processed_items):
            values = [item.get(cc['id'], "") for cc in columns_config]
            tag = 'oddrow' if idx % 2 else 'evenrow'
            item_iid_val = item.get(columns_config[0]['id'], generate_short_unique_id(f"item{idx}-")) 
            tree.insert("", tk.END, values=values, iid=str(item_iid_val), tags=(tag,))
        
        
        list_window.update_idletasks()

    search_button = ttk.Button(search_outer_frame, text="Ara", command=update_tree_display, width=8)
    search_button.pack(side=tk.LEFT, padx=(5,0))
    def clear_all():
        search_var.set("")
        for f_var in filter_widgets.values(): 
            f_var.set("Tümü")
        update_tree_display()

    clear_button = ttk.Button(search_outer_frame, text="Temizle", command=clear_all, width=10)
    clear_button.pack(side=tk.LEFT, padx=5)
    search_entry.bind("<Return>", update_tree_display)
    if filter_widgets:
      for f_var_widget in filter_widgets.values():
          f_var_widget.trace_add("write", update_tree_display)

    update_tree_display() 
    list_window.update() 

    if item_actions: 
        action_frame = ttk.Frame(list_window, padding="5")
        action_frame.pack(fill=tk.X, pady=(5,0))
        for action_text, action_command in item_actions:
            def on_action_click(command=action_command): 
                sel_focus = tree.focus() 
                if sel_focus: 
                    command(sel_focus) 
                else: 
                    messagebox.showwarning("Seçim Yok","Listeden bir öğe seçin.",parent=list_window)
            ttk.Button(action_frame,text=action_text,command=on_action_click).pack(side=tk.LEFT,padx=5)
            
    def on_close_list_win():
        global opened_list_windows
        if title_key in opened_list_windows: 
            del opened_list_windows[title_key]
        list_window.destroy()
    list_window.protocol("WM_DELETE_WINDOW", on_close_list_win)
    
    return list_window


def get_book_display_status(book_dict, all_lendings_list):
    for lending in all_lendings_list:
        if lending.get("book_id") == book_dict.get("id") and lending.get("return_date") is None:
            return "Ödünçte" 
    return book_dict.get("status", "Mevcut")

def list_books_handler():
    try:
        books_data_orig = load_data(BOOKS_FILE)
        lendings_data_orig = load_data(LENDINGS_FILE)
        display_books_list = []
        for book_item in books_data_orig:
            effective_status = get_book_display_status(book_item, lendings_data_orig)
            display_books_list.append({
                "id": book_item.get("id"),
                "title": book_item.get("title"),
                "author": book_item.get("author"),
                "persistent_status": book_item.get("status", "Mevcut"), 
                "status_display": effective_status 
            })
        cols_conf = [
            {"id": "id", "display": "ID", "width": 100, "stretch": tk.NO, "type": "text"},
            {"id": "title", "display": "Kitap Adı", "width": 300, "type": "text"},
            {"id": "author", "display": "Yazar", "width": 200, "type": "text"},
            {"id": "status_display", "display": "Durum", "width": 130, "type": "text"}
        ]
        search_conf = {"keys": ["id", "title", "author", "status_display"]} 
        filter_conf = [{ # Kitap durumu filtresi güncellendi
            "data_key": "status_display", "label": "Efektif Durum", 
            "options_override": ["Tümü", "Mevcut", "Mevcut Değil", "Kayıp", "Ödünçte"]
        }]
        create_list_window("books", "Kitap Listesi", display_books_list, cols_conf, search_conf, filter_conf)
    except Exception as e: 
        messagebox.showerror("Liste Hatası", f"Kitap listesi oluşturulurken hata: {str(e)}", parent=root)

def list_members_handler():
    try:
        members_data_orig = load_data(MEMBERS_FILE)
        cols_conf = [
            {"id": "id", "display": "ID", "width": 280, "stretch": tk.NO, "type": "text"}, 
            {"id": "name", "display": "Ad Soyad", "width": 200, "type": "text"},
            {"id": "phone1", "display": "Telefon 1", "width": 120, "type": "text"},
            {"id": "email", "display": "E-posta", "width": 180, "type": "text"}
        ]
        search_conf = {"keys": ["id", "name", "phone1", "phone2", "email"]}
        create_list_window("members", "Üye Listesi", members_data_orig, cols_conf, search_conf, 
                           item_actions=[("Üyeyi Sil", delete_member_handler)])
    except Exception as e: 
        messagebox.showerror("Liste Hatası", f"Üye listesi oluşturulurken hata: {str(e)}", parent=root)

def list_lent_books_handler():
    try:
        lendings_orig = load_data(LENDINGS_FILE)
        books_d = {b['id']: b for b in load_data(BOOKS_FILE)} 
        members_d = {m['id']: m for m in load_data(MEMBERS_FILE)}
        display_list = []
        for l_item in lendings_orig:
            if l_item.get("return_date") is None: 
                bk = books_d.get(l_item["book_id"])
                mem = members_d.get(l_item["member_id"])
                display_list.append({
                    "lending_id": l_item.get("lending_id", "-"),
                    "book_title": bk["title"] if bk else f"Silinmiş Kitap ({l_item['book_id']})",
                    "member_name": mem["name"] if mem else f"Silinmiş Üye ({l_item['member_id']})",
                    "lend_date": l_item["lend_date"]
                })
        cols_conf = [
            {"id": "lending_id", "display": "İşlem ID", "width":150, "type":"text"},
            {"id": "book_title", "display": "Kitap Adı", "width":250, "type":"text"},
            {"id": "member_name", "display": "Üye Adı", "width":200, "type":"text"},
            {"id": "lend_date", "display": "Veriliş Tarihi", "width":150, "type":"date"}
        ]
        search_conf = {"keys": ["lending_id", "book_title", "member_name", "lend_date"]}
        create_list_window("lendings", "Ödünç Verilen Kitaplar", display_list, cols_conf, 
                           search_conf, item_actions=[("İade Al", mark_as_returned_handler)])
    except Exception as e: 
        messagebox.showerror("Liste Hatası", f"Ödünç listesi oluşturulurken hata: {str(e)}", parent=root)

def mark_as_returned_handler(selected_lending_id):
    if not selected_lending_id: 
        messagebox.showwarning("Seçim Yok","İade için bir işlem seçmelisiniz.",parent=root)
        return
    try:
        lnds=load_data(LENDINGS_FILE)
        updated=False
        for l_item in lnds:
            if l_item.get("lending_id") == selected_lending_id and l_item.get("return_date") is None:
                l_item["return_date"] = datetime.date.today().isoformat()
                updated=True
                break
        if updated: 
            save_data(lnds,LENDINGS_FILE)
            messagebox.showinfo("Başarılı","Kitap başarıyla iade alındı.",parent=root)
            refresh_lending_list_if_open(True)
            refresh_book_list_if_open(True)
        else: 
            messagebox.showerror("Hata","İşlem bulunamadı veya zaten iade edilmiş.",parent=root)
    except Exception as e: 
        messagebox.showerror("İade Hatası",f"İade işlemi sırasında hata: {str(e)}",parent=root)


def refresh_list_window(title_key, handler_func):
    global opened_list_windows
    win = opened_list_windows.get(title_key)
    if win and win.winfo_exists():
        try: 
            win.destroy()
        except tk.TclError: 
            pass 
        if title_key in opened_list_windows: 
            del opened_list_windows[title_key]
    try: 
        handler_func()
    except Exception as e: 
        messagebox.showerror("Yenileme Hatası",f"{title_key} listesi yenilenirken hata: {str(e)}",parent=root)

def refresh_book_list_if_open(force=False):
    if force or opened_list_windows.get("books"): 
        refresh_list_window("books", list_books_handler)
def refresh_member_list_if_open(force=False):
    if force or opened_list_windows.get("members"): 
        refresh_list_window("members", list_members_handler)
def refresh_lending_list_if_open(force=False):
     if force or opened_list_windows.get("lendings"): 
        refresh_list_window("lendings", list_lent_books_handler)


root = tk.Tk()
root.title("Kütüphane Yönetim Sistemi")
root.geometry("460x500") 
style = ttk.Style()
main_app_frame = ttk.Frame(root,padding="10")
main_app_frame.pack(expand=True,fill=tk.BOTH)
app_main_title = ttk.Label(main_app_frame,text="Kütüphane İşlemleri",font=("TkDefaultFont",18,"bold"),anchor=tk.CENTER)
app_main_title.pack(pady=(10,20),fill=tk.X)
btn_width = 25 
books_f = ttk.LabelFrame(main_app_frame,text="Kitap İşlemleri",padding="10")
books_f.pack(pady=7,padx=5,fill=tk.X)
ttk.Button(books_f,text="Kitap Ekle",command=add_book_handler,width=btn_width).pack(pady=3,fill=tk.X,padx=5)
ttk.Button(books_f,text="Kitap Listele",command=list_books_handler,width=btn_width).pack(pady=3,fill=tk.X,padx=5)
ttk.Button(books_f,text="Kitap Düzenle",command=edit_book_handler,width=btn_width).pack(pady=3,fill=tk.X,padx=5)
members_f = ttk.LabelFrame(main_app_frame,text="Üye İşlemleri",padding="10")
members_f.pack(pady=7,padx=5,fill=tk.X)
ttk.Button(members_f,text="Üye Ekle",command=add_member_handler,width=btn_width).pack(pady=3,fill=tk.X,padx=5)
ttk.Button(members_f,text="Üye Listele",command=list_members_handler,width=btn_width).pack(pady=3,fill=tk.X,padx=5)
lending_f = ttk.LabelFrame(main_app_frame,text="Ödünç İşlemleri",padding="10")
lending_f.pack(pady=7,padx=5,fill=tk.X)
ttk.Button(lending_f,text="Kitap Ödünç Ver",command=lend_book_handler,width=btn_width).pack(pady=3,fill=tk.X,padx=5)
ttk.Button(lending_f,text="Ödünçteki Kitaplar",command=list_lent_books_handler,width=btn_width).pack(pady=3,fill=tk.X,padx=5)

if __name__ == "__main__":
    try: 
        root.mainloop()
    except Exception as e: 
        print(f"Ana uygulama döngüsünde kritik bir hata oluştu: {e}")
